"""
Initialize models package
"""
