"""
Initialize data package
"""
