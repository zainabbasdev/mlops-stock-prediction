"""
Initialize tests package
"""
